"""
ЗАДАНИЕ:
2. Дан список:

['в', '5', 'часов', '17', 'минут', 'температура', 'воздуха', 'была', '+5', 'градусов']
Необходимо его обработать — обособить каждое целое число кавычками и дополнить нулём до двух разрядов:
['в', '"', '05', '"', 'часов', '"', '17', '"', 'минут', 'температура', 'воздуха', 'была', '"', '+05', '"', 'градусов']
Новый список не создавать! Сформировать из обработанного списка строку:
в "05" часов "17" минут температура воздуха была "+05" градусов
"""
def str_consist_int(string):
    """

    :param string: string for test on int consist
    :return: True/False - it can/can't be translate to int
    """
    try:
        int(string)
        return(True)
    except ValueError:
        return(False)

list_of_int_index = []
list_for_parse = ['в', '5', 'часов', '17', 'минут', 'температура', 'воздуха', 'была', '+5', 'градусов']
#list_for_parse = ["Маск", "родился", "+28", "июня", "1971", "года", "в", "7", "часов",  "и", "заработал", "27.4", "млрд", "долларов"] #for test
# find index integer in list (list_for_parse)
for i in list_for_parse:
    if str_consist_int(i):
        list_of_int_index.append(list_for_parse.index(i))

# add 0 before one sign integers
for i in list_of_int_index:
    if len(str(abs(int(list_for_parse[i])))) == 1:
        list_for_parse[i] = list_for_parse[i][:-1]+'0'+list_for_parse[i][-1]

print("каждое целое число дополнить нулём до двух разрядов:")
print(list_for_parse)

# insert quotation marks both sides of integers
for i in list_of_int_index[::-1]:
    list_for_parse.insert(i + 1, '"')
    list_for_parse.insert(i, '"')
    #print(list_for_parse)
print("обособить каждое целое число кавычками:")
print(list_for_parse)

#формирование из обработанного списка строки (text):
#в "05" часов "17" минут температура воздуха была "+05" градусов

text = ""
for i in range(len(list_for_parse)):
    if (i>0 and list_for_parse[i-1] == '"' and str_consist_int(list_for_parse[i])) or (i>0 and str_consist_int(list_for_parse[i-1]) and list_for_parse[i] == '"'):
        text = text + list_for_parse[i]
    else:
        text = text +" "+ list_for_parse[i]

print("Сформировать из обработанного списка строку:")
print(text)

