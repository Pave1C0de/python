"""
ЗАДАНИЕ:
1. Выяснить тип результата выражений:

15 * 3
15 / 3
15 // 2
15 ** 2
"""

expressions = [[15 * 3, "15 * 3"],[15 / 3,"15/3"],[15 // 2, "15//2"],[15 ** 2, "15**2"]]

def get_type(exp, var):
    """
    :param exp: expression
    :param var: result of expression
    :return:   nothing, just print string: "{type(var)} тип результата выражения: {exp}"
    """
    type_in_str_format = str(type(var)).split("'")[1]
    print("{:<5} - тип результата выражения: {:>7}".format(type_in_str_format, exp))

print("{:^40}".format("ТИПЫ ВЫРАЖЕНИЙ."))
for expression in expressions:
    get_type(expression[1], expression[0])

