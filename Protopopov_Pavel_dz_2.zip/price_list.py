"""
5. Создать список, содержащий цены на товары (10–20 товаров), например:

[57.8, 46.51, 97, ...]
* Вывести на экран эти цены через запятую в одну строку, цена должна отображаться в виде <r> руб <kk> коп (например «5 руб 04 коп»).
 Подумать, как из цены получить рубли и копейки, как добавить нули, если, например, получилось 7 копеек или 0 копеек (должно быть 07 коп или 00 коп).

* Вывести цены, отсортированные по возрастанию, новый список не создавать (доказать, что объект списка после сортировки остался тот же).
* Создать новый список, содержащий те же цены, но отсортированные по убыванию.
* Вывести цены пяти самых дорогих товаров. Сможете ли вывести цены этих товаров по возрастанию, написав минимум кода?

Задачи со * предназначены для продвинутых учеников, которым мало сделать обычное задание.
"""
original_price_list = [3.50, 9.99, 1.20, 1.01, 57.8, 46.51, 97, 3.05, 0.05, 0.03]

def format_and_print_prices(price_list):
    out_price_string = ""
    for i in price_list:
        rubles = int(i//1)
        pences = int((i*100)%100)
        out_price_string += "{:} руб {:02} коп".format(rubles, pences)+", "
    print(out_price_string[:-2])

format_and_print_prices(original_price_list)
print("указатель на первый элемент списка не отсортированного списка:             {}".format(id(original_price_list)))
copy_of_original_price_list = original_price_list.copy()
print("=/"*30+"\n")

original_price_list.sort()
format_and_print_prices(original_price_list)
print("указатель на первый элемент списка отсортированного по возрастанию списка: {}".format(id(original_price_list)))
print("=/"*30+"\n")

copy_of_original_price_list.sort(reverse= True)
format_and_print_prices(copy_of_original_price_list)
print("указатель на первый элемент списка отсортированного по убыванию списка:    {}".format(id(copy_of_original_price_list)))
print("=/"*30+"\n")

format_and_print_prices(copy_of_original_price_list[:5])
format_and_print_prices(copy_of_original_price_list[4::-1])
print("=/"*30+"\n")
