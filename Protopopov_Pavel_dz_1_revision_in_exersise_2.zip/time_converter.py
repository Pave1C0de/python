'''
ЗАДАНИЕ:
1. Реализовать вывод информации о промежутке времени в зависимости от его продолжительности duration в секундах:
до минуты: <s> сек;
* до часа: <m> мин <s> сек;
* до суток: <h> час <m> мин <s> сек;
* *до месяца, до года, больше года: по аналогии.
'''
# secs + mins * 60 + hours * 60*60 + days * 60*60*24 + months * 60*60*24*30 + years * 60*60*24*30*12
SEC_IN_MIN   = 60
SEC_IN_HOUR  = 60 * 60
SEC_IN_DAY   = 60 * 60 * 24
SEC_IN_MONTH = 60 * 60 * 24 * 30                        #Допущение, что в каждом из 12 месяцев одинаковое количество дней
SEC_IN_YEAR  = 60 * 60 * 24 * 30 * 12
print("Please insert time duration in seconds")
time_duration = int(input("<<"))
#sec's
if time_duration < SEC_IN_MIN:
    print("{} сек".format(time_duration))
#min's
elif(SEC_IN_MIN <= time_duration < SEC_IN_HOUR):
    print("{} мин {} сек".format(time_duration // SEC_IN_MIN, time_duration % SEC_IN_MIN))
#hour's
elif(SEC_IN_HOUR <= time_duration < SEC_IN_DAY):
    print("{} час {} мин {} сек".format(time_duration // SEC_IN_HOUR, (time_duration % SEC_IN_HOUR) // SEC_IN_MIN, time_duration % SEC_IN_MIN))
#day's
elif(SEC_IN_DAY <= time_duration < SEC_IN_MONTH):
    print("{} день {} час {} мин {} сек".format(time_duration // SEC_IN_DAY, (time_duration % SEC_IN_DAY) // SEC_IN_HOUR, (time_duration % SEC_IN_HOUR) // SEC_IN_MIN, time_duration % SEC_IN_MIN))
#month's
elif(SEC_IN_MONTH <= time_duration < SEC_IN_YEAR):
    print("{} месяц {} день {} час {} мин {} сек".format(time_duration // SEC_IN_MONTH, (time_duration % SEC_IN_MONTH) // SEC_IN_DAY, (time_duration % SEC_IN_DAY) // SEC_IN_HOUR, (time_duration % SEC_IN_HOUR) // SEC_IN_MIN, time_duration % SEC_IN_MIN))
#year's
elif(SEC_IN_YEAR <= time_duration):
    print("{} год {} месяц {} день {} час {} мин {} сек".format(time_duration // SEC_IN_YEAR, (time_duration % SEC_IN_YEAR) // SEC_IN_MONTH, (time_duration % SEC_IN_MONTH) // SEC_IN_DAY, (time_duration % SEC_IN_DAY) // SEC_IN_HOUR, (time_duration % SEC_IN_HOUR) // SEC_IN_MIN, time_duration % SEC_IN_MIN))
else:
    pass
