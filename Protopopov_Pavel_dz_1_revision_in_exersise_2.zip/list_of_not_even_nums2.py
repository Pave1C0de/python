'''
ЗАДАНИЕ:
2. Создать список, состоящий из кубов нечётных чисел от 0 до 1000:
Вычислить сумму тех чисел из этого списка, сумма цифр которых делится нацело на 7.
Например, число «19 ^ 3 = 6859» будем включать в сумму, так как 6 + 8 + 5 + 9 = 28 – делится нацело на 7.
Внимание: использовать только арифметические операции!
К каждому элементу списка добавить 17 и заново вычислить сумму тех чисел из этого списка, сумма цифр которых делится нацело на 7.
Внимание: новый список не создавать!!!
'''




#КОММЕНТАРИЙ!!!!!!!!!!!!
'''
В задании, мне кажется, есть некая неодназначность: "Вычислить сумму тех чисел из этого списка..." Какого списка? (x или x^3) в первом части задания
и (x или (x^3)+17) во втором части задания. Из-за этого я привел для каждой части задания по 2 варианта ответа
'''





result_1 = 0 # сумма тех чисел из этого списка, сумма цифр которых делится нацело на 7. часть 1
result_2 = 0 # сумма тех чисел из этого списка, сумма цифр которых делится нацело на 7. часть 2
list_not_even_nums_in_3_pwr = list() # список, состоящий из кубов нечётных чисел от 0 до 1000
list_not_even_nums = list() # список, состоящий из нечетных чисел от 0 до 1000
def val_to_list_of_nums(val):
    """
    :param val: val = (10**n)*a + 10**(n-1)*b + 10**(n-2)*c +...+ 10**1*e + 10**0*f
    :return: nums = [a, b, c,... e, f]
    """
    nums = []
    while val > 0:
        nums.append(val % 10)
        val = val // 10
    return nums[::-1]

def result_calc_sum(list_not_even_nums_in_3_pwr):
    """
    :param list_not_even_nums_in_3_pwr: входящий список
    :return: сумму тех чисел из этого списка, сумма цифр которых делится нацело на 7.
    """
    result_x = 0
    result_x_in_3_pwr = 0
    for i in list_not_even_nums_in_3_pwr:
        sum_nums_from_list = 0
        # вычисление суммы цифр чисел для поиска тех, которые делятся нацело на 7
        for j in val_to_list_of_nums(i):
            sum_nums_from_list += j
        if sum_nums_from_list % 7 == 0:
            index_in_3_pwr = list_not_even_nums_in_3_pwr.index(i)
            #print(list_not_even_nums[index_in_3_pwr], i, val_to_list_of_nums(i), sum_nums_from_list)
            #result += sum_nums_from_list # was wrong
            result_x += list_not_even_nums[index_in_3_pwr]
            result_x_in_3_pwr += i
    return result_x, result_x_in_3_pwr

for i in range(1, 1000, 2):
    list_not_even_nums_in_3_pwr.append(i ** 3)
    list_not_even_nums.append(i)
result_1x, result_1x_in_3_pwr = result_calc_sum(list_not_even_nums_in_3_pwr)

print("/="*60)
print("Часть.1a Сумма чисел из этого списка {}..., сумма чисел кубов которых делится нацело на 7 равна {}".format(list_not_even_nums[0:4], result_1x))
print("Часть.1b Сумма чисел из этого списка {}..., сумма чисел которых делится нацело на 7 равна {}".format(list_not_even_nums_in_3_pwr[0:4], result_1x_in_3_pwr))
print("/="*60)
for i in range(len(list_not_even_nums_in_3_pwr)):
    list_not_even_nums_in_3_pwr[i] += 17
result_2x, result_2x_in_3_pwr = result_calc_sum(list_not_even_nums_in_3_pwr)
print("Часть.2a Сумма чисел из этого списка {}..., сумма чисел кубов которых c добавлением к ним 17 делится нацело на 7 равна {}".format(list_not_even_nums[0:4], result_2x))
print("Часть.2b Сумма чисел из этого списка {}..., сумма чисел которых c добавлением к ним 17 делится нацело на 7 равна {}".format(list_not_even_nums_in_3_pwr[0:4], result_2x_in_3_pwr))
print("/="*60)

