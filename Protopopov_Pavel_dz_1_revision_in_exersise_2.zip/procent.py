"""
3. Реализовать склонение слова «процент» для чисел до 20. Например,
 задаем число 5 — получаем «5 процентов», задаем число 2 — получаем «2 процента».
  Вывести все склонения для проверки.
"""
def procent_comment(num):
    """
    :param num: целое число до 20 к которому будет склоняться слово "процент"
    :return: число с комментарием
    """
    if type(num) == int:
        if num == 0 or (num >= 5 and num <= 20):
            return "процентов"
        elif num == 1:
            return "процент"
        elif num >=2 and num <= 4:
            return "процента"
        else:
            return "out of range!"
    else:
        return -1
for i in range(0,22):
    print(str(i)+" {}".format(procent_comment(i)))
print("X"+" {}".format(procent_comment("X")))